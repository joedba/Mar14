//
//  main.m
//  Mar14
//
//  Created by Joe Gabela on 3/24/13.
//  Copyright (c) 2013 Joe Gabela. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Mar14AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([Mar14AppDelegate class]));
    }
}
